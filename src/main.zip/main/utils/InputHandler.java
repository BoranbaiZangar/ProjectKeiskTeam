package main.utils;

public class InputHandler {
}
