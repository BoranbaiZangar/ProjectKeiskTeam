package main;

public class Obstacle {
}
