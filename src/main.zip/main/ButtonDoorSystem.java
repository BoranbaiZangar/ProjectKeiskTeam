package main;

public class ButtonDoorSystem {
}
